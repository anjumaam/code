package com.cg.contactbook.dao;

public interface QueryMapper {
	public static final String RETRIVE_ALL_DETAILS_QUERY="SELECT * from enquiry";
	public static final String GENERATE_SEQUENCE_QUERY="SELECT enquiries.NEXTVAL FROM dual";
	public static final String INSERTION_QUERY="INSERT INTO enquiry VALUES(?,?,?,?,?,?)";
}
