package com.cg.contactbook.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookexception;
import com.cg.contactbook.service.ContactBookService;
import com.cg.contactbook.service.ContactBookServiceImpl;



public class Client {
	

	public static void main(String[] args) throws ContactBookexception {
		Scanner sc = new Scanner(System.in);
		

		ContactBookService cbs = new ContactBookServiceImpl();
		
		
		do {
			System.out.println("**********Global Recruitments**********");
			System.out.println("1.Enter Enquiry Details");
			System.out.println("2.View All Enquiry Details");
			System.out.println("3.View Enquiry Details by Id");
			System.out.println("4.Exit");
			String option = sc.next();
			sc.nextLine();
			
			switch (option) {
			//**********For Adding Enquiry Details**************
			case "1":
				System.out.println("Enter First Name:");
				String fname = sc.nextLine();
				System.out.println("Enter Last Name:");
				String lname = sc.nextLine();
				System.out.println("Enter Contact Number:");
				String contactnumber = sc.nextLine();
				System.out.println("Enter Preferred Domain:");
				String pdomain = sc.nextLine();
				System.out.println("Enter Preferred Location:");
				String plocation = sc.nextLine();
				EnquiryBean enqry = new EnquiryBean(fname,lname,contactnumber,pdomain,plocation);
	
			
				try {
					int pid=0;
					if(cbs.isValidEnquiry(enqry))
						pid=cbs.addEnquiry(enqry);
				//	System.out.println("Sorry no details found.....!");
					System.out.println("Thank you"+enqry.getFname()+" "+enqry.getlName()+" "+"your unique id is:"+enqry.getEnqryid());
				} catch (ContactBookexception e) {
					
					System.err.println(e.getMessage());
				}
				break;
		
			case "2":
				
				
				List<EnquiryBean> plist= new ArrayList();
		
				try {
					plist=cbs.getEnquiryDetails();
					
					if(plist.size()==0) 
						System.out.println("no enquiry details available");
					else
					{
						for(EnquiryBean e1:plist)
						System.out.println(e1);	
					}
				} catch (ContactBookexception e) {
				System.out.println(e.getMessage());
				}
	
				break;
				
				
			case "3":
				System.out.println("Enter id to get the details");
				String eid=sc.next();
				if(Pattern.matches("[0-9]{4}",eid)){
					int id=Integer.parseInt(eid);
				EnquiryBean e;
				try {
					e=cbs.getDetails(id);
					System.out.println("Enquiry ID:"+e.getEnqryid()+"\n"+"  "+"FirstName:" +e.getFname()+"\n"+" "+"LastName: "+e.getlName()+"\n"+" "+"PreferredDomain"+e.getpDomain()+"\n"+" "+"Preferred Location"+e.getpLocation());
				} catch (ContactBookexception e1) {
					System.out.println(e1.getMessage());
				}
				}else System.err.println("enter Correct Id");
				break;
				
			case "4":
				System.exit(0);
				break;

			default:
				System.out.println("Enter correct choice");
				break;
			}
		
		} while (true);
		
	}

}
