package com.cg.contactbook.service;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.exception.ContactBookexception;



public class ContactBookServiceImpl implements ContactBookService {
	
	ContactBookDao dao = new ContactBookDaoImpl();
	public ContactBookServiceImpl() throws ContactBookexception {
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookexception {
		
		return dao.addEnquiry(enqry);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookexception {
	
		Boolean flag=true;
		String regx="^[A-Z]{1}[a-z]{4,19}$";
		String regx1="^[6-9][0-9]{9}$";
		String regx2="^[A-Za-z]{3,20}$";	
		String regx3="^[A-Za-z]{2,20}$";
		String regx4="^[A-Za-z]{2,20}$";
		
	
			if(!Pattern.matches((regx),enqry.getFname()))
			{
				flag=false;
				throw new ContactBookexception("Firstname should start with Capital letter & size should be 4 to 20");
			}
		
			if(!Pattern.matches(regx1,enqry.getContactNo()))
			{
				flag=false;
				throw new ContactBookexception("Contact number should be 10 digit valid mobile number ");
			}
			
			
			if(!Pattern.matches(regx2,enqry.getlName()))
			{
				flag=false;
				throw new ContactBookexception("Last name is required and it should not be empty ");
			}
			
			if(!Pattern.matches(regx3,enqry.getpLocation()))
			{
				flag=false;
				throw new ContactBookexception("Preferred Location is required and it should not be empty ");
			}

		
			if(!Pattern.matches(regx4,enqry.getpDomain()))
			{
				flag=false;
				throw new ContactBookexception("Preferred Domain is required and it should not be empty");
			}

		return flag;
	}

	@Override
	public List<EnquiryBean> getEnquiryDetails() throws ContactBookexception {
		
		return dao.getEnquiryDetails();
	}

	@Override
	public EnquiryBean getDetails(int id) throws ContactBookexception {
		
		return dao.getDetails(id);
	}

	

	

	

}
